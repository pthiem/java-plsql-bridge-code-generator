

// Generated source, do not edit, but you can extend.

package plsql_bridge.pkg_plsql_bridge_test;

import java.util.List;
import java.util.Map;
import java.util.Date;

public class P_test_numeric_simple_arguments {

	// Accessors
	
	
	
	public Long a_in_null;

        public void setA_in_null(Long a_in_null) {
            this.a_in_null = a_in_null;
        }
    
        public Long getA_in_null() {
            return a_in_null;
        }
	
	
	
	
	public Long a_in_value;

        public void setA_in_value(Long a_in_value) {
            this.a_in_value = a_in_value;
        }
    
        public Long getA_in_value() {
            return a_in_value;
        }
	
	
	
	
	public Long a_out_null;

        public void setA_out_null(Long a_out_null) {
            this.a_out_null = a_out_null;
        }
    
        public Long getA_out_null() {
            return a_out_null;
        }
	
	
	
	
	public Long a_in_null_out_null;

        public void setA_in_null_out_null(Long a_in_null_out_null) {
            this.a_in_null_out_null = a_in_null_out_null;
        }
    
        public Long getA_in_null_out_null() {
            return a_in_null_out_null;
        }
	
	
	
	
	public Long a_in_value_out_null;

        public void setA_in_value_out_null(Long a_in_value_out_null) {
            this.a_in_value_out_null = a_in_value_out_null;
        }
    
        public Long getA_in_value_out_null() {
            return a_in_value_out_null;
        }
	
	
	
	
	public Long a_in_null_out_value;

        public void setA_in_null_out_value(Long a_in_null_out_value) {
            this.a_in_null_out_value = a_in_null_out_value;
        }
    
        public Long getA_in_null_out_value() {
            return a_in_null_out_value;
        }
	
	
	
	
	public Long a_in_value_out_value;

        public void setA_in_value_out_value(Long a_in_value_out_value) {
            this.a_in_value_out_value = a_in_value_out_value;
        }
    
        public Long getA_in_value_out_value() {
            return a_in_value_out_value;
        }
	
	
	
}

