Java PLSQL Bridge Code Generator
--------------------------------
See wiki for information.

https://github.com/pthiem/Java-PLSQL-Bridge-Code-Generator/wiki
