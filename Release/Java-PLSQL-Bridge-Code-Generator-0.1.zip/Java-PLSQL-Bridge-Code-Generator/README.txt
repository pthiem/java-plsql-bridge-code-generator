Java PLSQL Bridge Code Generator
--------------------------------
See wiki for information.
