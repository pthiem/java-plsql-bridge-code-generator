

// Generated source, do not edit, but you can extend.

package plsql_bridge.pkg_plsql_bridge_test;

import java.util.List;
import java.util.Map;
import java.util.Date;

public class P_get_cursor_untyped_arguments {

	// Accessors
	
	
	
	public Long a_number;

        public void setA_number(Long a_number) {
            this.a_number = a_number;
        }
    
        public Long getA_number() {
            return a_number;
        }
	
	
	
	
	public List < Map >  acur_uptyped;

        public void setAcur_uptyped(List < Map >  acur_uptyped) {
            this.acur_uptyped = acur_uptyped;
        }
    
        public List < Map >  getAcur_uptyped() {
            return acur_uptyped;
        }
	
	
	
}

