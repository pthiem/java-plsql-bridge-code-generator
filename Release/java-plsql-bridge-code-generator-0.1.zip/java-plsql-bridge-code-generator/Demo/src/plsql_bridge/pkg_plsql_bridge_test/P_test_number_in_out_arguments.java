

// Generated source, do not edit, but you can extend.

package plsql_bridge.pkg_plsql_bridge_test;

import java.util.List;
import java.util.Map;
import java.util.Date;

public class P_test_number_in_out_arguments {

	// Accessors
	
	
	
	public Long fld_number_in_null_out_null;

        public void setFld_number_in_null_out_null(Long fld_number_in_null_out_null) {
            this.fld_number_in_null_out_null = fld_number_in_null_out_null;
        }
    
        public Long getFld_number_in_null_out_null() {
            return fld_number_in_null_out_null;
        }
	
	
	
	
	public Long fld_number_in_null_out_value;

        public void setFld_number_in_null_out_value(Long fld_number_in_null_out_value) {
            this.fld_number_in_null_out_value = fld_number_in_null_out_value;
        }
    
        public Long getFld_number_in_null_out_value() {
            return fld_number_in_null_out_value;
        }
	
	
	
	
	public Long fld_number_in_value_out_null;

        public void setFld_number_in_value_out_null(Long fld_number_in_value_out_null) {
            this.fld_number_in_value_out_null = fld_number_in_value_out_null;
        }
    
        public Long getFld_number_in_value_out_null() {
            return fld_number_in_value_out_null;
        }
	
	
	
	
	public Long fld_number_in_value_out_value;

        public void setFld_number_in_value_out_value(Long fld_number_in_value_out_value) {
            this.fld_number_in_value_out_value = fld_number_in_value_out_value;
        }
    
        public Long getFld_number_in_value_out_value() {
            return fld_number_in_value_out_value;
        }
	
	
	
	
	public String result;

        public void setResult(String result) {
            this.result = result;
        }
    
        public String getResult() {
            return result;
        }
	
	
	
}

