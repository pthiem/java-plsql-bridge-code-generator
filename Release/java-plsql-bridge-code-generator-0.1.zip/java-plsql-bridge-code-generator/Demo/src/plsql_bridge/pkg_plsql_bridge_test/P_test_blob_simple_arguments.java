

// Generated source, do not edit, but you can extend.

package plsql_bridge.pkg_plsql_bridge_test;

import java.util.List;
import java.util.Map;
import java.util.Date;

public class P_test_blob_simple_arguments {

	// Accessors
	
	
	
	public byte[] a_in_null;

        public void setA_in_null(byte[] a_in_null) {
            this.a_in_null = a_in_null;
        }
    
        public byte[] getA_in_null() {
            return a_in_null;
        }
	
	
	
	
	public byte[] a_in_value;

        public void setA_in_value(byte[] a_in_value) {
            this.a_in_value = a_in_value;
        }
    
        public byte[] getA_in_value() {
            return a_in_value;
        }
	
	
	
	
	public byte[] a_out_null;

        public void setA_out_null(byte[] a_out_null) {
            this.a_out_null = a_out_null;
        }
    
        public byte[] getA_out_null() {
            return a_out_null;
        }
	
	
	
	
	public byte[] a_out_value;

        public void setA_out_value(byte[] a_out_value) {
            this.a_out_value = a_out_value;
        }
    
        public byte[] getA_out_value() {
            return a_out_value;
        }
	
	
	
	
	public byte[] a_in_null_out_null;

        public void setA_in_null_out_null(byte[] a_in_null_out_null) {
            this.a_in_null_out_null = a_in_null_out_null;
        }
    
        public byte[] getA_in_null_out_null() {
            return a_in_null_out_null;
        }
	
	
	
	
	public byte[] a_in_value_out_null;

        public void setA_in_value_out_null(byte[] a_in_value_out_null) {
            this.a_in_value_out_null = a_in_value_out_null;
        }
    
        public byte[] getA_in_value_out_null() {
            return a_in_value_out_null;
        }
	
	
	
	
	public byte[] a_in_null_out_value;

        public void setA_in_null_out_value(byte[] a_in_null_out_value) {
            this.a_in_null_out_value = a_in_null_out_value;
        }
    
        public byte[] getA_in_null_out_value() {
            return a_in_null_out_value;
        }
	
	
	
	
	public byte[] a_in_value_out_value;

        public void setA_in_value_out_value(byte[] a_in_value_out_value) {
            this.a_in_value_out_value = a_in_value_out_value;
        }
    
        public byte[] getA_in_value_out_value() {
            return a_in_value_out_value;
        }
	
	
	
}

