

// Generated source, do not edit, but you can extend.

package plsql_bridge.pkg_plsql_bridge_test;

import java.util.List;
import java.util.Map;
import java.util.Date;

public class P_test_types_out_simple_arguments {

	// Accessors
	
	
	
	public Long fld_number_null;

        public void setFld_number_null(Long fld_number_null) {
            this.fld_number_null = fld_number_null;
        }
    
        public Long getFld_number_null() {
            return fld_number_null;
        }
	
	
	
	
	public Long fld_number_value;

        public void setFld_number_value(Long fld_number_value) {
            this.fld_number_value = fld_number_value;
        }
    
        public Long getFld_number_value() {
            return fld_number_value;
        }
	
	
	
	
	public Double fld_number_float;

        public void setFld_number_float(Double fld_number_float) {
            this.fld_number_float = fld_number_float;
        }
    
        public Double getFld_number_float() {
            return fld_number_float;
        }
	
	
	
	
	public Double fld_number_float_null;

        public void setFld_number_float_null(Double fld_number_float_null) {
            this.fld_number_float_null = fld_number_float_null;
        }
    
        public Double getFld_number_float_null() {
            return fld_number_float_null;
        }
	
	
	
	
	public Long fld_numeric_null;

        public void setFld_numeric_null(Long fld_numeric_null) {
            this.fld_numeric_null = fld_numeric_null;
        }
    
        public Long getFld_numeric_null() {
            return fld_numeric_null;
        }
	
	
	
	
	public Long fld_numeric_value;

        public void setFld_numeric_value(Long fld_numeric_value) {
            this.fld_numeric_value = fld_numeric_value;
        }
    
        public Long getFld_numeric_value() {
            return fld_numeric_value;
        }
	
	
	
	
	public Double fld_float;

        public void setFld_float(Double fld_float) {
            this.fld_float = fld_float;
        }
    
        public Double getFld_float() {
            return fld_float;
        }
	
	
	
	
	public Double fld_float_null;

        public void setFld_float_null(Double fld_float_null) {
            this.fld_float_null = fld_float_null;
        }
    
        public Double getFld_float_null() {
            return fld_float_null;
        }
	
	
	
	
	public Double fld_double;

        public void setFld_double(Double fld_double) {
            this.fld_double = fld_double;
        }
    
        public Double getFld_double() {
            return fld_double;
        }
	
	
	
	
	public Double fld_double_null;

        public void setFld_double_null(Double fld_double_null) {
            this.fld_double_null = fld_double_null;
        }
    
        public Double getFld_double_null() {
            return fld_double_null;
        }
	
	
	
	
	public String fld_varchar2;

        public void setFld_varchar2(String fld_varchar2) {
            this.fld_varchar2 = fld_varchar2;
        }
    
        public String getFld_varchar2() {
            return fld_varchar2;
        }
	
	
	
	
	public String fld_varchar2_null;

        public void setFld_varchar2_null(String fld_varchar2_null) {
            this.fld_varchar2_null = fld_varchar2_null;
        }
    
        public String getFld_varchar2_null() {
            return fld_varchar2_null;
        }
	
	
	
	
	public Date fld_date;

        public void setFld_date(Date fld_date) {
            this.fld_date = fld_date;
        }
    
        public Date getFld_date() {
            return fld_date;
        }
	
	
	
	
	public Date fld_date_null;

        public void setFld_date_null(Date fld_date_null) {
            this.fld_date_null = fld_date_null;
        }
    
        public Date getFld_date_null() {
            return fld_date_null;
        }
	
	
	
	
	public String fld_char;

        public void setFld_char(String fld_char) {
            this.fld_char = fld_char;
        }
    
        public String getFld_char() {
            return fld_char;
        }
	
	
	
	
	public String fld_char_null;

        public void setFld_char_null(String fld_char_null) {
            this.fld_char_null = fld_char_null;
        }
    
        public String getFld_char_null() {
            return fld_char_null;
        }
	
	
	
	
	public Double fld_subtype;

        public void setFld_subtype(Double fld_subtype) {
            this.fld_subtype = fld_subtype;
        }
    
        public Double getFld_subtype() {
            return fld_subtype;
        }
	
	
	
}

