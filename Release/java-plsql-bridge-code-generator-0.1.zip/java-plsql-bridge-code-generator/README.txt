Java PLSQL Bridge Code Generator
--------------------------------
See wiki for information.

https://github.com/pthiem/java-plsql-bridge-code-generator/wiki
