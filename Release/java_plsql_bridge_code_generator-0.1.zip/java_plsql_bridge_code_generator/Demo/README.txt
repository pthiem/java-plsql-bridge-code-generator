Running the Demo
-----------------
See wiki for information.

https://github.com/pthiem/java_plsql_bridge_code_generator/wiki#wiki-run_the_demo
