Running the Demo
-----------------
See wiki for information.
